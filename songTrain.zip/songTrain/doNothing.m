function [Yret, mu] = doNothing (Y, Rtr, Rte, U, M, friends, mu, dim)
%first method: do nothing and only use the centering
Yret = Y;
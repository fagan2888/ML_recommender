function [mean] = calculateMean (Y, R)

mean = 